# Aruk — Web + CLI + SDK Archive

**"Keeper of secrets and keys"** — Centralized API key management system.

---

## Archive Stats

| Module | Files | Lines | Language(s) |
|--------|-------|-------|-------------|
| **Web Dashboard** | 93 | 12,214 | TypeScript, CSS, Prisma |
| **SDK** | 3 | — | TypeScript |
| **CLI** | 1 | 423 | TypeScript |
| **TOTAL** | **97** | **13,637** | — |

---

## Directory Structure

```
aruk-archive/
├── MANIFEST.md              <-- this file
├── web/                      Next.js Web Dashboard
│   ├── config/                package.json, tsconfig, tailwind, postcss, etc.
│   ├── prisma/                Database schema + seed script
│   ├── scripts/               CLI tool + Tauri bundle script
│   └── src/
│       ├── app/                  Pages + 15 API routes
│       ├── components/
│       │   ├── api-bank/          9 dashboard tabs (main UI)
│       │   └── ui/                40 shadcn/ui primitives
│       ├── hooks/                Custom React hooks
│       └── lib/
│           ├── sdk/                TypeScript SDK client
│           ├── api-bank/           API bank lib
│           ├── agent-plugin/       Agent plugin
│           ├── db.ts               Prisma client
│           └── utils.ts            Utilities
└── cli/
    └── aruk-cli.ts            CLI tool (423 lines)
```

---

## 1. Web Dashboard (Next.js)

**Stack:** Next.js App Router + Prisma + SQLite + Tailwind CSS + shadcn/ui + Recharts
**Style:** Glassmorphism, emerald green brand, oklch dark/light mode

### API Routes (15 endpoints)

| Route | Methods | Purpose |
|-------|---------|---------|
| `/api` | GET | Root API info |
| `/api/accounts` | GET, PUT | List/update accounts (13 protected read-only fields) |
| `/api/accounts/toggle` | POST | Enable/disable account |
| `/api/agent` | POST | AI agent endpoint |
| `/api/credits` | GET | Credit monitoring |
| `/api/export` | GET | Data export |
| `/api/health` | GET | Server health check |
| `/api/predictions` | GET | Credit predictions |
| `/api/providers` | GET | Provider list |
| `/api/routing` | POST | Smart key routing |
| `/api/secrets` | GET, POST, PUT, DELETE | Secrets CRUD |
| `/api/simulate` | POST | Load simulation |
| `/api/stats` | GET | Global statistics |
| `/api/usage/daily` | GET | Daily usage data |
| `/api/usage/logs` | GET | Usage logs |

### Dashboard Tabs (9)

| Tab | File | Description |
|-----|------|-------------|
| Overview | `overview-tab.tsx` | High-level status cards |
| Dashboard | `dashboard.tsx` | Main dashboard view |
| Accounts | `accounts-tab.tsx` | API key management with read-only credit panel |
| Analytics | `analytics-tab.tsx` | Usage charts (Recharts) |
| Routing | `routing-tab.tsx` | Smart routing configuration |
| Vault | `vault-tab.tsx` | Secrets management |
| Credit Monitor | `credit-monitor-tab.tsx` | Capitec-style credit balance view |
| Simulate | `simulate-tab.tsx` | Load testing simulation |
| CLI | `cli-tab.tsx` | Embedded CLI interface |

### Protected Fields Pattern

Server strips 13 system-tracked fields on PUT `/api/accounts`:
`totalCredits`, `usedCredits`, `creditUnit`, `healthScore`, `avgLatencyMs`,
`successRate`, `totalRequests`, `todayRequests`, `errorCount`, `lastUsedAt`,
`remainingCredits`, `remainingPercent`, `createdAt`, `updatedAt`

---

## 2. TypeScript SDK

**Location:** `web/src/lib/sdk/index.ts`

Provides a typed client for all Aruk API endpoints. Used by both the web dashboard and as a reference for other platform SDKs (Android Retrofit, etc.).

---

## 3. CLI Tool

**Location:** `cli/aruk-cli.ts` (423 lines)

Full command-line interface for interacting with the Aruk API — list keys, add keys, smart routing, status checks, and more.

---

## Design Language

- **Emerald green** brand color (`#10B981`)
- **Glassmorphism** UI (frosted glass cards, blur, subtle borders)
- **Dark/light mode** with oklch color space
- **Protected read-only metrics** (Capitec bank-balance style credits)

---

## Build Requirements

| Module | Requirements |
|--------|-------------|
| Web | Node.js 18+ / Bun, SQLite3 |
| CLI | Bun or Node.js with tsx |
